ASHIL JEEJO — FREE STATIC WEBSITE

This is the first version of your personal filmmaker website.

Files:
- index.html — the complete website

Before publishing:
1. Open index.html in a browser and check it.
2. Replace YOUR-EMAIL@example.com with your real professional email.
3. Replace the Instagram / film-profile placeholders with your real links.
4. Send me your other projects, photos, credits and preferred bio and I can expand the site.

FREE HOSTING:
You can publish this for ₹0 using GitHub Pages or another free static host. I can walk you through the exact clicks after you download the ZIP.
